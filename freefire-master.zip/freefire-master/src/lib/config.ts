import type { RechargePackage } from './types';

export const UPI_ID = 'mytopup@upi'; // Placeholder UPI ID
export const COUPON_CODE = "GAMEON5";

export const bgmiPackages: RechargePackage[] = [
  { id: 1, name: '60 UC', price: 89, currency: 'INR', bonus: '+5 UC' },
  { id: 2, name: '325 UC', price: 449, currency: 'INR', bonus: '+25 UC' },
  { id: 3, name: '660 UC', price: 899, currency: 'INR', bonus: '+60 UC', bestSeller: true },
  { id: 4, name: '1800 UC', price: 2299, currency: 'INR', bonus: '+180 UC' },
  { id: 5, name: '3850 UC', price: 4499, currency: 'INR', bonus: '+400 UC' },
  { id: 6, name: '8100 UC', price: 8999, currency: 'INR', bonus: '+850 UC' },
];

export const freeFirePackages: RechargePackage[] = [
  { id: 1, name: '100 Diamonds', price: 79, currency: 'INR', bonus: '+10 Diamonds' },
  { id: 2, name: '310 Diamonds', price: 249, currency: 'INR', bonus: '+31 Diamonds' },
  { id: 3, name: '520 Diamonds', price: 399, currency: 'INR', bonus: '+52 Diamonds', bestSeller: true },
  { id: 4, name: '1060 Diamonds', price: 749, currency: 'INR', bonus: '+106 Diamonds' },
  { id: 5, name: '2180 Diamonds', price: 1399, currency: 'INR', bonus: '+218 Diamonds' },
  { id: 6, name: '5600 Diamonds', price: 3499, currency: 'INR', bonus: '+560 Diamonds' },
];

export const heroImage = "https://placehold.co/1920x1080.png";
export const bgmiLogo = "https://placehold.co/150x150.png";
export const bgmiLogoWidth = 120;
export const bgmiLogoHeight = 120;
export const freeFireLogo = "https://placehold.co/150x150.png";
export const freeFireLogoWidth = 120;
export const freeFireLogoHeight = 120;
