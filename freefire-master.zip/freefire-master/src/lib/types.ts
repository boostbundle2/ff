export interface RechargePackage {
  id: number;
  name: string;
  price: number;
  currency: string;
  bonus?: string;
  bestSeller?: boolean;
}
