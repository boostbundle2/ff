'use server';

import { z } from 'zod';

const OrderSchema = z.object({
  game: z.enum(['bgmi', 'free-fire']),
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  playerId: z.string().min(5, { message: 'Player ID seems too short.' }),
  transactionId: z.string().min(10, { message: 'Transaction ID is required.' }),
  // Screenshot is not handled here as files are complex with server actions without more setup.
  // The form component will just have the input for show.
});

export async function submitOrderAction(prevState: any, formData: FormData) {
  const validatedFields = OrderSchema.safeParse({
    game: formData.get('game'),
    name: formData.get('name'),
    playerId: formData.get('playerId'),
    transactionId: formData.get('transactionId'),
  });

  if (!validatedFields.success) {
    return {
      errors: validatedFields.error.flatten().fieldErrors,
      message: 'Error: Please check your inputs.',
    };
  }
  
  // In a real app, you would send an email or save to a database here.
  console.log('New Order Submitted:', validatedFields.data);

  return { message: 'Success! Your order details have been submitted.' };
}


const ContactSchema = z.object({
    name: z.string().min(2, "Name is required."),
    email: z.string().email("Invalid email address."),
    message: z.string().min(10, "Message must be at least 10 characters."),
});


export async function submitContactForm(prevState: any, formData: FormData) {
    const validatedFields = ContactSchema.safeParse({
        name: formData.get('name'),
        email: formData.get('email'),
        message: formData.get('message'),
    });

    if (!validatedFields.success) {
        return {
            errors: validatedFields.error.flatten().fieldErrors,
            message: 'Error: Please fix the errors below.',
        };
    }

    // In a real app, you would send an email or save to a database here.
    console.log('New Contact Message:', validatedFields.data);

    return { message: 'Success! Your message has been sent.' };
}
