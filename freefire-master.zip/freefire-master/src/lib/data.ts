// This file is deprecated. Please use src/lib/config.ts instead.
export {};
