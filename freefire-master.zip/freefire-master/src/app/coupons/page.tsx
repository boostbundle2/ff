
import type { Metadata } from 'next';
import { COUPON_CODE } from '@/lib/config';
import CouponDisplay from '@/components/coupon-display';
import { Gift, Tag, CheckCircle } from 'lucide-react';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Coupons & Offers - 5% Discount on Game Top-Ups',
  description: 'Find the latest coupons and offers for GameTopUp Zone. Get a 5% discount on BGMI UC and Free Fire Diamonds with our exclusive promo code.',
  alternates: {
    canonical: '/coupons',
  },
};

export default function CouponsPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 max-w-4xl">
      <div className="flex flex-col items-center text-center mb-12">
        <Gift className="h-16 w-16 text-primary mb-4" />
        <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">Coupons & Special Offers</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Save on your next purchase with our exclusive discount codes.
        </p>
      </div>

      <div className="mb-12">
        <h2 className="text-2xl font-bold font-headline text-center mb-6">Current Active Coupon</h2>
        <CouponDisplay code={COUPON_CODE} />
      </div>

      <div className="space-y-8 text-left bg-card p-8 rounded-lg border border-primary/20">
        <div>
          <h3 className="flex items-center gap-3 text-xl font-bold font-headline text-foreground mb-3">
            <Tag className="h-6 w-6 text-accent" />
            How to Apply Your Coupon
          </h3>
          <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
            <li>Select your desired package on either the <Link href="/bgmi" className="text-primary transition-colors hover:underline">BGMI Recharge</Link> or <Link href="/free-fire" className="text-primary transition-colors hover:underline">Free Fire Top-Up</Link> page.</li>
            <li>In the recharge card, find the "Coupon Code" input field.</li>
            <li>Enter or paste the code <strong className="text-accent">{COUPON_CODE}</strong> into the field and click "Apply".</li>
            <li>The discount will be applied, and you will see the new, lower price.</li>
            <li>Proceed with the payment to complete your purchase at the discounted rate.</li>
          </ol>
        </div>
        <div>
          <h3 className="flex items-center gap-3 text-xl font-bold font-headline text-foreground mb-3">
            <CheckCircle className="h-6 w-6 text-accent" />
            Offer Benefits
          </h3>
          <p className="text-muted-foreground">
            By using the coupon code, you will receive a <strong className="text-primary">5% discount</strong> on the total price of any BGMI UC or Free Fire Diamond package. This is our way of saying thank you to our loyal customers!
          </p>
        </div>
      </div>
    </div>
  );
}
