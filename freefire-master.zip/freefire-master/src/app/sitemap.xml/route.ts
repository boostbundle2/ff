
// app/sitemap.xml/route.ts
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://gametopup.zone';

const staticRoutes = [
  '', 
  '/bgmi', 
  '/free-fire', 
  '/submit-order',
  '/contact',
  '/about',
  '/coupons',
  '/delivery-policy',
  '/disclaimer',
  '/privacy-policy',
  '/refund-policy',
  '/terms-and-conditions',
  '/sitemap'
];

export async function GET() {
  const lastModified = new Date().toISOString();

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${staticRoutes.map((route) => `
    <url>
      <loc>${SITE_URL}${route}</loc>
      <lastmod>${lastModified}</lastmod>
      <changefreq>weekly</changefreq>
      <priority>${route === '' ? '1.0' : '0.8'}</priority>
    </url>
  `).join('')}
</urlset>`;

  return new Response(sitemap, {
    headers: {
      'Content-Type': 'application/xml',
    },
  });
}
