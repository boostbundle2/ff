import type { Metadata } from 'next';
import Image from 'next/image';
import { Gamepad2, Heart, Zap, ShieldCheck } from 'lucide-react';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'About GameTopUp Zone',
  description: 'Learn about GameTopUp Zone, your trusted source for fast and secure BGMI UC and Free Fire Diamond recharges in India. Our mission is to provide the best service for gamers.',
  alternates: {
    canonical: '/about',
  },
};

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6">
      <div className="flex flex-col items-center text-center mb-12">
        <Gamepad2 className="h-16 w-16 text-primary mb-4" />
        <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">About GameTopUp Zone</h1>
        <p className="mt-2 text-lg text-muted-foreground max-w-2xl">
          Your #1 Destination for In-Game Currency in India.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
        <div className="space-y-6">
          <h2 className="text-3xl font-bold font-headline text-foreground">Our Story</h2>
          <p className="text-muted-foreground">
            GameTopUp Zone was born from a simple idea: topping up your favorite games shouldn't be a hassle. As passionate gamers ourselves, we were tired of slow, unreliable services and complicated payment processes. We knew there had to be a better way.
          </p>
          <p className="text-muted-foreground">
            We started as a small service for our local gaming community, manually processing recharges to ensure every transaction was perfect. Word spread, and soon we were serving gamers all across India. Today, we're proud to be one of the most trusted names for BGMI and Free Fire top-ups, but our core mission remains the same.
          </p>
        </div>
        <div>
          <Image 
            src="https://placehold.co/600x400.png"
            data-ai-hint="gaming setup"
            alt="A modern gaming setup"
            width={600}
            height={400}
            className="rounded-lg shadow-lg"
          />
        </div>
      </div>
      
      <div className="bg-card p-8 rounded-lg border border-primary/20 mb-16">
        <h2 className="text-3xl font-bold font-headline text-center text-primary mb-8">Our Core Mission</h2>
        <div className="grid sm:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center gap-3">
              <div className="p-3 bg-primary/10 rounded-full">
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold text-xl">Speed</h3>
              <p className="text-muted-foreground text-sm">Deliver recharges in minutes, not hours. Get back to the game faster than ever.</p>
            </div>
             <div className="flex flex-col items-center gap-3">
              <div className="p-3 bg-primary/10 rounded-full">
                <ShieldCheck className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold text-xl">Security</h3>
              <p className="text-muted-foreground text-sm">Provide a secure and trustworthy platform with verified UPI and careful manual handling.</p>
            </div>
             <div className="flex flex-col items-center gap-3">
              <div className="p-3 bg-primary/10 rounded-full">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold text-xl">Service</h3>
              <p className="text-muted-foreground text-sm">Offer dedicated support for every gamer. Your satisfaction is our highest priority.</p>
            </div>
        </div>
      </div>

       <div className="text-center">
        <h2 className="text-3xl font-bold font-headline text-foreground mb-4">Join Thousands of Happy Gamers</h2>
        <p className="text-muted-foreground mb-6">
          Ready to experience the best top-up service in India?
        </p>
        <div className="flex justify-center gap-4">
           <Link href="/bgmi" className="inline-block bg-primary text-primary-foreground font-bold py-3 px-6 rounded-lg transition hover:bg-primary/90">Recharge BGMI</Link>
           <Link href="/free-fire" className="inline-block bg-secondary text-secondary-foreground font-bold py-3 px-6 rounded-lg transition hover:bg-secondary/80">Top-Up Free Fire</Link>
        </div>
      </div>

    </div>
  );
}
