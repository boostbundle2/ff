import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import Script from 'next/script';
import { Space_Grotesk } from 'next/font/google';
import { cn } from '@/lib/utils';
import PageLoader from '@/components/page-loader';
import { LanguageProvider } from '@/hooks/use-language';

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
});

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://gametopup.zone';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: 'GameTopUp Zone - Instant BGMI & Free Fire Recharge',
    template: '%s | GameTopUp Zone',
  },
  description: 'Recharge BGMI UC and Free Fire Diamonds instantly with UPI. Trusted by over 10,000 gamers for fast and secure top-ups. Buy BGMI UC India and get Free Fire Diamond Top-Up UPI.',
  keywords: ['Buy BGMI UC India', 'Free Fire Diamond Top-Up UPI', 'BGMI UC', 'Free Fire Diamonds', 'Game Top-Up', 'Gaming Recharge', 'UPI Payments', 'Instant UC', 'Diamond Top Up'],
  openGraph: {
    title: {
      default: 'GameTopUp Zone - Instant BGMI & Free Fire Recharge',
      template: '%s | GameTopUp Zone',
    },
    description: 'The fastest and most trusted way to recharge in-game currency for BGMI and Free Fire in India.',
    url: SITE_URL,
    siteName: 'GameTopUp Zone',
    images: [
      {
        url: `/og-image.png`, 
        width: 1200,
        height: 630,
        alt: 'GameTopUp Zone - BGMI and Free Fire Recharge',
      },
    ],
    locale: 'en_IN',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: {
      default: 'GameTopUp Zone - Instant BGMI & Free Fire Recharge',
      template: '%s | GameTopUp Zone',
    },
    description: 'Instant BGMI UC and Free Fire Diamond recharges with UPI. Safe, fast, and reliable.',
    images: [`/twitter-image.png`], 
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const organizationSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'GameTopUp Zone',
    url: SITE_URL,
    logo: `${SITE_URL}/logo.png`, 
    sameAs: [
      'https://instagram.com/GameTopUpZone', 
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+91-XXX-XXX-XXXX', 
      contactType: 'Customer Service',
      email: 'support@gametopup.zone',
    },
  };

  return (
    <html lang="en" className={cn("dark", spaceGrotesk.variable)}>
      <head>
         <Script
          id="org-schema"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
        />
      </head>
      <body className="font-body antialiased">
        <LanguageProvider>
          <PageLoader />
          <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-grow">
              {children}
            </main>
            <Footer />
          </div>
          <Toaster />
        </LanguageProvider>
      </body>
    </html>
  );
}
