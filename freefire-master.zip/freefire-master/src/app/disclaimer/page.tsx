import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Disclaimer',
  description: 'Disclaimer for GameTopUp Zone.',
};

// Use a fixed date to avoid hydration mismatch
const lastUpdatedDate = new Date('2024-07-26').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });


export default function DisclaimerPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 max-w-4xl">
      <h1 className="text-4xl font-bold font-headline text-primary mb-6">Disclaimer</h1>
      <div className="space-y-6 text-muted-foreground">
        <p>Last updated: {lastUpdatedDate}</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">General Information</h2>
        <p>The information provided by GameTopUp Zone ("we," "us," or "our") on this website is for general informational purposes only. All information on the site is provided in good faith, however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the site.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Affiliation Disclaimer</h2>
        <p>GameTopUp Zone is an independent entity and is not affiliated with, endorsed, sponsored, or specifically approved by Krafton, Garena, or any of the game developers for which we provide top-up services. The names BGMI, Free Fire, and any other game titles, logos, and brands are the property of their respective owners.</p>
        
        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">External Links Disclaimer</h2>
        <p>The site may contain links to other websites or content belonging to or originating from third parties. Such external links are not investigated, monitored, or checked for accuracy, adequacy, validity, reliability, availability, or completeness by us. We do not warrant, endorse, guarantee, or assume responsibility for the accuracy or reliability of any information offered by third-party websites linked through the site.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Limitation of Liability</h2>
        <p>Under no circumstance shall we have any liability to you for any loss or damage of any kind incurred as a result of the use of the site or reliance on any information provided on the site. Your use of the site and your reliance on any information on the site is solely at your own risk.</p>
      </div>
    </div>
  );
}
