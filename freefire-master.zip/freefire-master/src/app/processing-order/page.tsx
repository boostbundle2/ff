
'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Hourglass, Wallet, CheckCircle } from 'lucide-react';
import Link from 'next/link';

export default function ProcessingOrderPage() {
  const searchParams = useSearchParams();
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds

  const upiLink = searchParams.get('upi');

  useEffect(() => {
    // On initial page load, attempt to open the UPI app.
    if (upiLink) {
      window.location.href = upiLink;
    }
  }, [upiLink]); 

  useEffect(() => {
    if (timeLeft === 0) return;

    const intervalId = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearInterval(intervalId);
  }, [timeLeft]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  
  const handleRetryPayment = () => {
    if (upiLink) {
        window.location.href = upiLink;
    }
  }

  return (
    <div className="container mx-auto max-w-2xl px-4 py-12 md:px-6 flex items-center justify-center min-h-[70vh]">
      <Card className="w-full text-center shadow-lg border-primary/40">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <Hourglass className="h-12 w-12 text-primary animate-spin" style={{ animationDuration: '3s' }} />
          </div>
          <CardTitle className="text-3xl font-bold font-headline text-primary">Your Order is Being Processed</CardTitle>
          <CardDescription className="text-lg text-muted-foreground pt-2">
            Please complete the payment in your UPI app.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="bg-secondary p-4 rounded-lg">
                <p className="font-bold text-4xl text-foreground tracking-widest">
                    {`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`}
                </p>
                <p className="text-xs text-muted-foreground">Time left to complete payment</p>
            </div>

            <div className="text-left space-y-4 p-4 bg-card rounded-md border">
                <h3 className="text-lg font-bold font-headline text-foreground flex items-center gap-2"><CheckCircle className="h-5 w-5 text-accent"/>What to do next:</h3>
                <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                    <li>Open your UPI application (like GPay, PhonePe, etc.). If it didn't open automatically, click the "Retry Payment" button below.</li>
                    <li>Approve the payment request from "GameTopUp Zone".</li>
                    <li>Once payment is successful, come back to this page.</li>
                    <li>
                       After payment, you must <Link href="/submit-order" className="text-primary underline hover:text-primary/80">submit your order details.</Link>
                       <strong className="text-primary"> This step is required!</strong>
                    </li>
                </ol>
            </div>
          
          <Button onClick={handleRetryPayment} size="lg" className="w-full bg-primary text-primary-foreground hover:bg-primary/90" disabled={!upiLink}>
            <Wallet className="mr-2"/>
            Retry Payment
          </Button>

        </CardContent>
      </Card>
    </div>
  );
}
