import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import Link from "next/link";
import Script from 'next/script';

const faqItems = [
  {
    question: "How long does the delivery take?",
    answer: "Most top-ups are completed within 5-15 minutes after you've submitted your payment and order details. During peak hours, it may take up to 2 hours."
  },
  {
    question: "Is this website safe and trustworthy?",
    answer: "Absolutely. We use secure UPI for payments and every transaction is handled manually with care to ensure accuracy. We have served over 10,000 satisfied gamers."
  },
  {
    question: "What should I do after making the payment?",
    answer: "After paying via UPI, you must go to the 'Submit Order' page and fill in your details, including the UPI transaction ID. This is a crucial step for us to process your order."
  },
  {
    question: "What if I enter the wrong Player ID?",
    answer: "It is very important to double-check your Player ID. Orders are processed based on the ID you provide, and we cannot refund or transfer the in-game currency if the wrong ID is submitted. Please see our Refund Policy for more details."
  },
  {
    question: "How can I contact support?",
    answer: "If you have any issues or questions, you can reach out to us through our Contact Page. We're always here to help!"
  }
];

const faqPageSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqItems.map(faq => ({
    '@type': 'Question',
    name: faq.question,
    acceptedAnswer: {
      '@type': 'Answer',
      text: faq.answer
        .replace(/Contact Page/g, 'our Contact Page (gametopup.zone/contact)')
        .replace(/Refund Policy/g, 'our Refund Policy (gametopup.zone/refund-policy)')
        .replace(/'Submit Order' page/g, 'the \'Submit Order\' page (gametopup.zone/submit-order)'),
    },
  })),
};

export default function Faq() {
  return (
    <>
      <Script
        id="faq-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqPageSchema) }}
      />
      <Accordion type="single" collapsible className="w-full">
        {faqItems.map((faq, index) => (
          <AccordionItem key={index} value={`item-${index}`}>
            <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              {faq.answer.includes("Contact Page") ? (
                   <>
                      If you have any issues or questions, you can reach out to us through our <Link href="/contact" className="text-primary transition-colors hover:underline">Contact Page</Link>. We're always here to help!
                   </>
              ) : faq.answer.includes("Refund Policy") ? (
                  <>
                      It is very important to double-check your Player ID. Orders are processed based on the ID you provide, and we cannot refund or transfer the in-game currency if the wrong ID is submitted. Please see our <Link href="/refund-policy" className="text-primary transition-colors hover:underline">Refund Policy</Link> for more details.
                  </>
              ) : faq.answer.includes("'Submit Order'") ? (
                   <>
                      After paying via UPI, you must go to the <Link href="/submit-order" className="text-primary transition-colors hover:underline">'Submit Order'</Link> page and fill in your details, including the UPI transaction ID. This is a crucial step for us to process your order.
                   </>
              ) : (
                faq.answer
              )}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </>
  )
}
