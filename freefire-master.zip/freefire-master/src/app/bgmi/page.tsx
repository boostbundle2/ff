import type { Metadata } from 'next';
import RechargeCard from '@/components/recharge-card';
import { bgmiPackages, UPI_ID, bgmiLogo, COUPON_CODE, bgmiLogoWidth, bgmiLogoHeight } from '@/lib/config';
import Image from 'next/image';
import CouponDisplay from '@/components/coupon-display';
import Script from 'next/script';

export const metadata: Metadata = {
  title: 'Buy BGMI UC Online - Instant Recharge India',
  description: 'Purchase BGMI UC at the best prices in India. Get instant UC delivery with secure UPI payments. Choose from various UC packs and recharge your Battlegrounds Mobile India account in minutes.',
  keywords: ['BGMI UC', 'Buy BGMI UC', 'BGMI Recharge', 'UC Top Up', 'BGMI UC India', 'Battlegrounds Mobile India UC'],
  alternates: {
    canonical: '/bgmi',
  },
};

export default function BgmiPage() {
   const productSchema = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: 'BGMI Unknown Cash (UC)',
    description: 'In-game currency for Battlegrounds Mobile India (BGMI) to purchase items, season passes, and more.',
    image: bgmiLogo,
    brand: {
      '@type': 'Brand',
      name: 'BGMI',
    },
    offers: {
      '@type': 'AggregateOffer',
      priceCurrency: 'INR',
      highPrice: bgmiPackages[bgmiPackages.length - 1].price,
      lowPrice: bgmiPackages[0].price,
      offerCount: bgmiPackages.length,
      offers: bgmiPackages.map(pkg => ({
        '@type': 'Offer',
        price: pkg.price,
        priceCurrency: 'INR',
        name: pkg.name,
        availability: 'https://schema.org/InStock',
        seller: {
          '@type': 'Organization',
          name: 'GameTopUp Zone',
        },
      })),
    },
  };

  return (
    <div className="container mx-auto px-4 py-12 md:px-6">
       <Script
        id="bgmi-product-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }}
      />
      <div className="flex flex-col items-center text-center mb-8">
        <Image src={bgmiLogo} data-ai-hint="battlegrounds mobile" alt="BGMI Logo" width={bgmiLogoWidth} height={bgmiLogoHeight} className="mb-4 rounded-xl" />
        <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">BGMI UC Recharge</h1>
        <p className="mt-2 text-lg text-muted-foreground max-w-2xl">
          Select a UC pack, enter your BGMI Player ID, and pay with any UPI app.
          Your UC will be credited to your account shortly.
        </p>
      </div>

      <div className="mb-8">
        <CouponDisplay code={COUPON_CODE} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        {bgmiPackages.map((pkg) => (
          <RechargeCard key={pkg.id} pkg={pkg} gameName="BGMI" upiId={UPI_ID} />
        ))}
      </div>

       <div className="mt-16 text-center bg-card p-6 rounded-lg border border-primary/20">
            <h2 className="text-2xl font-bold font-headline text-primary">How to find your BGMI Player ID?</h2>
            <p className="text-muted-foreground mt-2">1. Open the BGMI game on your device.</p>
            <p className="text-muted-foreground">2. Go to your profile section in the top-left corner.</p>
            <p className="text-muted-foreground">3. Your Player ID is displayed below your nickname. Tap to copy.</p>
        </div>
    </div>
  );
}
