import type { Metadata } from 'next';
import ContactForm from '@/components/contact-form';
import { Mail, Instagram } from 'lucide-react';
import Script from 'next/script';

export const metadata: Metadata = {
  title: 'Contact Us - GameTopUp Zone Support',
  description: 'Have a question or need support with your BGMI UC or Free Fire Diamond order? Contact the GameTopUp Zone team via our form or social media for a quick response.',
  alternates: {
    canonical: '/contact',
  },
};

export default function ContactPage() {
  const contactPageSchema = {
    '@context': 'https://schema.org',
    '@type': 'ContactPage',
    name: 'Contact GameTopUp Zone',
    description: 'Get support for your game top-up orders or ask any questions.',
    url: 'https://gametopup.zone/contact', // Replace with your domain
  };

  return (
    <div className="container mx-auto px-4 py-12 md:px-6">
      <Script
        id="contact-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(contactPageSchema) }}
      />
      <div className="grid md:grid-cols-2 gap-12 items-start">
        <div className="space-y-6">
          <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">Get in Touch</h1>
          <p className="text-lg text-muted-foreground">
            We're here to help you with any questions or issues. Reach out to us through the form or our social channels.
          </p>
          <div className="space-y-4">
            <a href="mailto:support@gametopup.zone" className="flex items-center gap-3 p-4 bg-card rounded-lg border border-border transition-colors hover:border-primary">
              <Mail className="h-8 w-8 text-primary" />
              <div>
                <h3 className="font-semibold">Email Us</h3>
                <p className="text-muted-foreground">support@gametopup.zone</p>
              </div>
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 p-4 bg-card rounded-lg border border-border transition-colors hover:border-primary">
              <Instagram className="h-8 w-8 text-primary" />
              <div>
                <h3 className="font-semibold">Follow us on Instagram</h3>
                <p className="text-muted-foreground">@GameTopUpZone</p>
              </div>
            </a>
          </div>
        </div>
        <div>
          <ContactForm />
        </div>
      </div>
    </div>
  );
}
