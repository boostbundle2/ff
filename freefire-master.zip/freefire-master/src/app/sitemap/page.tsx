
import type { Metadata } from 'next';
import Link from 'next/link';
import { LayoutGrid, Gamepad, FileText, ShoppingCart, User, MessageSquare, Tag } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Sitemap',
  description: 'A complete overview of all pages on GameTopUp Zone.',
  alternates: {
    canonical: '/sitemap',
  },
};

const mainPages = [
    { href: '/', label: 'Home', icon: LayoutGrid },
    { href: '/bgmi', label: 'BGMI Recharge', icon: Gamepad },
    { href: '/free-fire', label: 'Free Fire Top-Up', icon: Gamepad },
    { href: '/submit-order', label: 'Submit Order Details', icon: ShoppingCart },
    { href: '/coupons', label: 'Coupons & Offers', icon: Tag },
    { href: '/about', label: 'About Us', icon: User },
    { href: '/contact', label: 'Contact Us', icon: MessageSquare },
];

const legalPages = [
    { href: '/terms-and-conditions', label: 'Terms & Conditions', icon: FileText },
    { href: '/privacy-policy', label: 'Privacy Policy', icon: FileText },
    { href: '/refund-policy', label: 'Refund Policy', icon: FileText },
    { href: '/delivery-policy', label: 'Delivery Policy', icon: FileText },
    { href: '/disclaimer', label: 'Disclaimer', icon: FileText },
];

export default function SitemapPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 max-w-4xl">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">Sitemap</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Find all pages on our website at a glance.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-4">
          <h2 className="text-2xl font-bold font-headline text-accent">Main Pages</h2>
           <div className="space-y-2">
            {mainPages.map((page) => (
                <Link key={page.href} href={page.href} className="flex items-center gap-3 p-3 bg-card rounded-lg border border-border transition-colors hover:border-primary hover:bg-card/50">
                    <page.icon className="h-5 w-5 text-primary" />
                    <span className="font-medium text-foreground">{page.label}</span>
                </Link>
            ))}
          </div>
        </div>
        <div className="space-y-4">
          <h2 className="text-2xl font-bold font-headline text-accent">Legal &amp; Info</h2>
           <div className="space-y-2">
             {legalPages.map((page) => (
                <Link key={page.href} href={page.href} className="flex items-center gap-3 p-3 bg-card rounded-lg border border-border transition-colors hover:border-primary hover:bg-card/50">
                    <page.icon className="h-5 w-5 text-primary" />
                    <span className="font-medium text-foreground">{page.label}</span>
                </Link>
            ))}
          </div>
        </div>
      </div>
       <div className="mt-16 text-center text-muted-foreground text-sm">
        <p>Looking for the XML sitemap for search engines? You can find it <Link href="/sitemap.xml" className="text-primary underline">here</Link>.</p>
      </div>
    </div>
  );
}
