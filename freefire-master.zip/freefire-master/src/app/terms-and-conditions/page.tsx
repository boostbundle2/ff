import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Terms & Conditions',
  description: 'Terms and Conditions for using GameTopUp Zone.',
};

export default function TermsAndConditionsPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 max-w-4xl">
      <h1 className="text-4xl font-bold font-headline text-primary mb-6">Terms & Conditions</h1>
      <div className="space-y-6 text-muted-foreground">
        <p>Please read these terms and conditions carefully before using Our Service.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">1. Introduction</h2>
        <p>By accessing or using the GameTopUp Zone website (the "Service"), you agree to be bound by these Terms & Conditions. If you disagree with any part of the terms, you may not access the Service.</p>
        
        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">2. Purchases</h2>
        <p>If you wish to purchase any product or service made available through the Service, you will be asked to supply certain information relevant to your purchase, including your in-game Player ID. You are responsible for providing an accurate Player ID. We are not liable for any loss or delay resulting from an incorrect Player ID provided by you.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">3. Payments</h2>
        <p>All payments are processed via UPI. By making a payment, you confirm that the payment method used is yours. All transactions are final. Please refer to our <Link href="/refund-policy" className="text-primary transition-colors hover:underline">Refund Policy</Link> for details on refunds.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">4. User Conduct</h2>
        <p>You agree not to use the Service for any unlawful purpose or any purpose prohibited under this clause. You agree not to use the Service in any way that could damage the Service, the reputation of GameTopUp Zone, or the general enjoyment of other users.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">5. Limitation of Liability</h2>
        <p>In no event shall GameTopUp Zone, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.</p>
        
        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">6. Governing Law</h2>
        <p>These Terms shall be governed and construed in accordance with the laws of India, without regard to its conflict of law provisions.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">7. Changes to Terms</h2>
        <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms on this page.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">8. Contact Us</h2>
        <p>If you have any questions about these Terms, please contact us at <a href="mailto:support@gametopup.zone" className="text-primary transition-colors hover:underline">support@gametopup.zone</a>.</p>
      </div>
    </div>
  );
}
