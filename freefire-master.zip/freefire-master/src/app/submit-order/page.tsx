import type { Metadata } from 'next';
import OrderSubmissionForm from '@/components/order-submission-form';

export const metadata: Metadata = {
  title: 'Submit Order Details',
  description: 'After payment, submit your order details here to get your recharge processed quickly.',
};

export default function SubmitOrderPage() {
  return (
    <div className="container mx-auto max-w-2xl px-4 py-12 md:px-6">
      <div className="flex flex-col items-center text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">Submit Your Order</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Paid for your top-up? Fill out this form with your payment details to complete your order.
        </p>
      </div>
      <OrderSubmissionForm />
    </div>
  );
}
