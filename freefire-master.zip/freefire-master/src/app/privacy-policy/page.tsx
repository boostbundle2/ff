import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Privacy Policy for GameTopUp Zone.',
};

// Use a fixed date to avoid hydration mismatch
const lastUpdatedDate = new Date('2024-07-26').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });


export default function PrivacyPolicyPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 max-w-4xl">
      <h1 className="text-4xl font-bold font-headline text-primary mb-6">Privacy Policy</h1>
      <div className="space-y-6 text-muted-foreground">
        <p>Last updated: {lastUpdatedDate}</p>
        
        <p>GameTopUp Zone ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how your personal information is collected, used, and disclosed by GameTopUp Zone.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">1. Information We Collect</h2>
        <p>We collect information you provide directly to us. For example, we collect information when you make a purchase, contact customer support, or otherwise communicate with us. The types of information we may collect include:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Transaction Information:</strong> Your in-game Player ID, the game you are purchasing for (e.g., BGMI, Free Fire), and details of the package you purchase.</li>
          <li><strong>Contact Information:</strong> Your name and email address when you contact us or submit an order form.</li>
          <li><strong>Payment Information:</strong> UPI transaction ID and optional screenshots to verify payments.</li>
        </ul>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">2. How We Use Your Information</h2>
        <p>We use the information we collect to:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Process your transactions and deliver the in-game currency to your account.</li>
          <li>Communicate with you about your orders, including confirmations and support.</li>
          <li>Respond to your comments, questions, and requests.</li>
          <li>Monitor and analyze trends, usage, and activities in connection with our services.</li>
        </ul>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">3. Information Sharing</h2>
        <p>We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties. We only use your information for the purpose of fulfilling your order.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">4. Data Security</h2>
        <p>We implement a variety of security measures to maintain the safety of your personal information when you place an order. However, no method of transmission over the Internet or method of electronic storage is 100% secure.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">5. Your Rights</h2>
        <p>You have the right to request access to the personal information we hold about you and to ask that your personal information be corrected, updated, or deleted. If you would like to exercise this right, please contact us.</p>
        
        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">6. Changes to This Policy</h2>
        <p>We may update this privacy policy from time to time. We will notify you of any changes by posting the new privacy policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">7. Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us at <a href="mailto:support@gametopup.zone" className="text-primary transition-colors hover:underline">support@gametopup.zone</a>.</p>
      </div>
    </div>
  );
}
