import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Refund Policy',
  description: 'Refund Policy for GameTopUp Zone.',
};

// Use a fixed date to avoid hydration mismatch
const lastUpdatedDate = new Date('2024-07-26').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });


export default function RefundPolicyPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 max-w-4xl">
      <h1 className="text-4xl font-bold font-headline text-primary mb-6">Refund Policy</h1>
      <div className="space-y-6 text-muted-foreground">
        <p>Last updated: {lastUpdatedDate}</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">General Policy</h2>
        <p>All sales on GameTopUp Zone are final. We provide digital products in the form of in-game currency, and due to the nature of these products, we generally do not offer refunds or exchanges once a purchase is completed and the currency has been delivered.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">When Refunds Are Possible</h2>
        <p>A refund will only be considered under the following circumstance:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Failed Recharge:</strong> If we fail to deliver the in-game currency to your account due to a technical error or issue on our side, you will be eligible for a full refund.</li>
        </ul>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">When Refunds Are Not Possible</h2>
        <p>We are not responsible for and will not issue a refund for:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Incorrect Player ID:</strong> If you provide an incorrect Player ID / UID, the recharge will be sent to that ID and we cannot reverse it. It is your responsibility to ensure the ID is correct.</li>
          <li><strong>Change of Mind:</strong> We do not offer refunds if you change your mind after the purchase.</li>
          <li><strong>Banned Accounts:</strong> We are not responsible if your game account is banned or suspended for any reason.</li>
        </ul>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">How to Request a Refund</h2>
        <p>If you believe you are eligible for a refund based on a failed recharge from our end, please contact our support team within 24 hours of the transaction. You can reach us via our <Link href="/contact" className="text-primary transition-colors hover:underline">Contact Page</Link> or by emailing <a href="mailto:support@gametopup.zone" className="text-primary transition-colors hover:underline">support@gametopup.zone</a>. Please provide your Order ID and UPI Transaction ID.</p>
        
        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Processing Time</h2>
        <p>Upon receiving a valid refund request, we will investigate the issue. If a failed recharge is confirmed on our side, the refund will be processed to your original payment method within 5-7 business days.</p>
      </div>
    </div>
  );
}
