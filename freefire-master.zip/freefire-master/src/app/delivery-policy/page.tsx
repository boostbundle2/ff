import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Delivery Policy',
  description: 'Delivery Policy for GameTopUp Zone.',
};

// Use a fixed date to avoid hydration mismatch
const lastUpdatedDate = new Date('2024-07-26').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });


export default function DeliveryPolicyPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 max-w-4xl">
      <h1 className="text-4xl font-bold font-headline text-primary mb-6">Delivery Policy</h1>
      <div className="space-y-6 text-muted-foreground">
        <p>Last updated: {lastUpdatedDate}</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Delivery Method</h2>
        <p>All products sold on GameTopUp Zone are digital. The in-game currency (such as BGMI UC or Free Fire Diamonds) is delivered directly to the game account associated with the Player ID / UID you provide during the purchase process.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Delivery Timeframe</h2>
        <p>We pride ourselves on our fast delivery. Most orders are processed and delivered within <strong>5 to 15 minutes</strong> after a successful payment and order submission.</p>
        <p>However, during peak times, high order volumes, or in rare cases of technical issues, delivery might take up to 2 hours. We appreciate your patience in such scenarios.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Incorrect Information</h2>
        <p>It is crucial that you provide the correct <strong>Player ID / UID</strong>. We are not responsible for any loss or delay caused by incorrect information submitted by the customer. Once an order is processed for a specific ID, it cannot be reversed or refunded. Please double-check your ID before completing the payment.</p>

        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Order Confirmation & Submission</h2>
        <p>After making a payment via UPI, you must fill out the <Link href="/submit-order" className="text-primary transition-colors hover:underline">Submit Order</Link> form on our website. This step is essential for us to verify your payment and process your top-up. Your order delivery timeframe begins after you have successfully submitted this form.</p>
        
        <h2 className="text-2xl font-bold font-headline text-foreground pt-4">Contact Us</h2>
        <p>If you have not received your top-up within the specified timeframe or have any questions regarding your order, please do not hesitate to <Link href="/contact" className="text-primary transition-colors hover:underline">Contact Us</Link> with your UPI Transaction ID.</p>
      </div>
    </div>
  );
}
