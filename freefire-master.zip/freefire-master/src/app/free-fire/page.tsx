import type { Metadata } from 'next';
import RechargeCard from '@/components/recharge-card';
import { freeFirePackages, UPI_ID, freeFireLogo, COUPON_CODE, freeFireLogoWidth, freeFireLogoHeight } from '@/lib/config';
import Image from 'next/image';
import CouponDisplay from '@/components/coupon-display';
import Script from 'next/script';

export const metadata: Metadata = {
  title: 'Free Fire Diamond Top-Up - Instant & Secure UPI',
  description: 'Top-up Garena Free Fire Diamonds instantly using any UPI app. Get the best deals on diamond packs in India. Enter your Player ID and receive your diamonds in minutes.',
  keywords: ['Free Fire Diamonds', 'Free Fire Top Up', 'Diamond Top Up UPI', 'Garena Free Fire', 'Buy Free Fire Diamonds'],
  alternates: {
    canonical: '/free-fire',
  },
};

export default function FreeFirePage() {
  const productSchema = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: 'Garena Free Fire Diamonds',
    description: 'In-game currency for Garena Free Fire to purchase characters, skins, and other exclusive items.',
    image: freeFireLogo,
    brand: {
      '@type': 'Brand',
      name: 'Garena Free Fire',
    },
    offers: {
      '@type': 'AggregateOffer',
      priceCurrency: 'INR',
      highPrice: freeFirePackages[freeFirePackages.length - 1].price,
      lowPrice: freeFirePackages[0].price,
      offerCount: freeFirePackages.length,
      offers: freeFirePackages.map(pkg => ({
        '@type': 'Offer',
        price: pkg.price,
        priceCurrency: 'INR',
        name: pkg.name,
        availability: 'https://schema.org/InStock',
        seller: {
          '@type': 'Organization',
          name: 'GameTopUp Zone',
        },
      })),
    },
  };

  return (
    <div className="container mx-auto px-4 py-12 md:px-6">
      <Script
        id="ff-product-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }}
      />
      <div className="flex flex-col items-center text-center mb-8">
        <Image src={freeFireLogo} data-ai-hint="garena free fire" alt="Free Fire Logo" width={freeFireLogoWidth} height={freeFireLogoHeight} className="mb-4 rounded-xl" />
        <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">Free Fire Diamond Top-Up</h1>
        <p className="mt-2 text-lg text-muted-foreground max-w-2xl">
          Choose your diamond pack, provide your Free Fire Player ID, and complete the payment using any UPI app.
        </p>
      </div>

      <div className="mb-8">
        <CouponDisplay code={COUPON_CODE} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        {freeFirePackages.map((pkg) => (
          <RechargeCard key={pkg.id} pkg={pkg} gameName="Free Fire" upiId={UPI_ID} />
        ))}
      </div>

      <div className="mt-16 text-center bg-card p-6 rounded-lg border border-primary/20">
            <h2 className="text-2xl font-bold font-headline text-primary">How to find your Free Fire Player ID?</h2>
            <p className="text-muted-foreground mt-2">1. Open the Garena Free Fire game on your device.</p>
            <p className="text-muted-foreground">2. Click on your profile in the top-left corner.</p>
            <p className="text-muted-foreground">3. Your Player ID is shown below your username. Use the copy button next to it.</p>
      </div>
    </div>
  );
}
