
'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ShieldCheck, Zap, UserCheck, ArrowRight, HelpCircle } from 'lucide-react';
import Testimonials from '@/components/testimonials';
import PurchaseToast from '@/components/purchase-toast';
import Faq from '@/components/faq';
import { heroImage } from '@/lib/config';
import Script from 'next/script';
import { useTranslation } from '@/hooks/use-language';
import WelcomePopup from '@/components/welcome-popup';

export default function Home() {
  const t = useTranslation();
  const websiteSchema = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    url: 'https://gametopup.zone', // Replace with your actual domain
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: 'https://gametopup.zone/search?q={search_term_string}', // Replace with your search page
      },
      'query-input': 'required name=search_term_string',
    },
  };
  
  return (
    <div className="flex flex-col">
       <Script
        id="website-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
      />
      <WelcomePopup />
      {/* Hero Section */}
      <section className="relative h-[60vh] md:h-[80vh] w-full flex items-center justify-center text-center text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <Image
          src={heroImage}
          alt="Gaming background with characters"
          data-ai-hint="gaming characters collage"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 container mx-auto px-4 md:px-6">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-headline tracking-tighter">
            {t('home.title')}
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg md:text-xl text-primary font-medium">
            {t('home.subtitle')}
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 transition-transform hover:scale-105">
              <Link href="/bgmi">{t('home.rechargeBgmi')} <ArrowRight className="ml-2" /></Link>
            </Button>
            <Button asChild size="lg" variant="secondary" className="transition-transform hover:scale-105">
              <Link href="/free-fire">{t('home.topUpFreeFire')} <ArrowRight className="ml-2" /></Link>
            </Button>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent z-10" />
      </section>

      {/* Trust Section */}
      <section id="trust" className="py-12 md:py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid gap-8 md:grid-cols-3 text-center">
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 bg-primary/10 rounded-full">
                <ShieldCheck className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-xl font-bold font-headline">{t('home.trust.upi')}</h3>
              <p className="text-muted-foreground">{t('home.trust.upiDesc')}</p>
            </div>
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 bg-primary/10 rounded-full">
                <Zap className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-xl font-bold font-headline">{t('home.trust.fast')}</h3>
              <p className="text-muted-foreground">{t('home.trust.fastDesc')}</p>
            </div>
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 bg-primary/10 rounded-full">
                <UserCheck className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-xl font-bold font-headline">{t('home.trust.manual')}</h3>
              <p className="text-muted-foreground">{t('home.trust.manualDesc')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-12 md:py-24 bg-secondary">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-headline">
            {t('home.testimonialsTitle')}
          </h2>
          <Testimonials />
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-12 md:py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6 max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-headline flex items-center justify-center gap-3">
            <HelpCircle className="h-8 w-8 text-primary" />
            {t('home.faqTitle')}
          </h2>
          <Faq />
        </div>
      </section>

      <PurchaseToast />
    </div>
  );
}
