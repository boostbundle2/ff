'use client';
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { bgmiPackages, freeFirePackages, UPI_ID, heroImage, bgmiLogo, freeFireLogo, COUPON_CODE, bgmiLogoWidth, bgmiLogoHeight, freeFireLogoWidth, freeFireLogoHeight } from "@/lib/config";
import { useToast } from "@/hooks/use-toast";
import AdminAuth from "./admin-auth";
import { Separator } from "./ui/separator";

const packageSchema = z.object({
  id: z.number(),
  name: z.string(),
  price: z.number(),
  currency: z.string(),
  bonus: z.string().optional(),
});

const themeColorSchema = z.string().regex(/^\d+\s\d+%\s\d+%$/, "Must be a valid HSL color string (e.g., '210 40% 96%')");

const configSchema = z.object({
  upiId: z.string().min(1, "UPI ID is required"),
  couponCode: z.string().min(1, "Coupon Code is required"),
  heroImage: z.string().url("Must be a valid URL"),
  bgmiLogo: z.string().url("Must be a valid URL"),
  bgmiLogoWidth: z.number().min(1, "Width is required"),
  bgmiLogoHeight: z.number().min(1, "Height is required"),
  freeFireLogo: z.string().url("Must be a valid URL"),
  freeFireLogoWidth: z.number().min(1, "Width is required"),
  freeFireLogoHeight: z.number().min(1, "Height is required"),
  bgmiPackages: z.array(packageSchema),
  freeFirePackages: z.array(packageSchema),
  theme: z.object({
      background: themeColorSchema,
      foreground: themeColorSchema,
      card: themeColorSchema,
      primary: themeColorSchema,
      accent: themeColorSchema,
      border: themeColorSchema,
      ring: themeColorSchema,
  }),
});

type ConfigFormValues = z.infer<typeof configSchema>;

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { toast } = useToast();

  const { register, handleSubmit, formState: { errors }, getValues } = useForm<ConfigFormValues>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      upiId: UPI_ID,
      couponCode: COUPON_CODE,
      heroImage: heroImage,
      bgmiLogo: bgmiLogo,
      bgmiLogoWidth: bgmiLogoWidth,
      bgmiLogoHeight: bgmiLogoHeight,
      freeFireLogo: freeFireLogo,
      freeFireLogoWidth: freeFireLogoWidth,
      freeFireLogoHeight: freeFireLogoHeight,
      bgmiPackages: bgmiPackages,
      freeFirePackages: freeFirePackages,
      theme: {
          background: "0 0% 13%",
          foreground: "0 0% 98%",
          card: "0 0% 15%",
          primary: "183 100% 74%",
          accent: "120 61% 50%",
          border: "0 0% 25%",
          ring: "183 100% 74%",
      }
    }
  });

  const onSubmit = (data: ConfigFormValues) => {
    // In a real application, this would trigger a server action to write to a file or database.
    // For this prototype, we'll just show a success message.
    console.log("Updated config:", data);
    toast({
      title: "Success!",
      description: "Configuration updated. (This is a demo - changes are not saved).",
    });
  };

  if (!isAuthenticated) {
    return <AdminAuth onSuccess={() => setIsAuthenticated(true)} />;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Admin Panel</CardTitle>
        <CardDescription>Manage your store settings, products, and appearance from here.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          
          <h3 className="text-xl font-bold font-headline text-primary">General Settings</h3>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="upiId">Merchant UPI ID</Label>
              <Input id="upiId" {...register("upiId")} />
              {errors.upiId && <p className="text-sm text-destructive">{errors.upiId.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="couponCode">Coupon Code</Label>
              <Input id="couponCode" {...register("couponCode")} />
              {errors.couponCode && <p className="text-sm text-destructive">{errors.couponCode.message}</p>}
            </div>
          </div>

          <Separator />

          <h3 className="text-xl font-bold font-headline text-primary">Branding &amp; Appearance</h3>
           <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="heroImage">Hero Image URL</Label>
              <Input id="heroImage" {...register("heroImage")} />
              {errors.heroImage && <p className="text-sm text-destructive">{errors.heroImage.message}</p>}
            </div>
            
             <div className="space-y-2">
              <Label htmlFor="bgmiLogo">BGMI Logo URL</Label>
              <Input id="bgmiLogo" {...register("bgmiLogo")} />
              {errors.bgmiLogo && <p className="text-sm text-destructive">{errors.bgmiLogo.message}</p>}
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="bgmiLogoWidth">BGMI Logo Width</Label>
                    <Input id="bgmiLogoWidth" type="number" {...register("bgmiLogoWidth", { valueAsNumber: true })} />
                    {errors.bgmiLogoWidth && <p className="text-sm text-destructive">{errors.bgmiLogoWidth.message}</p>}
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="bgmiLogoHeight">BGMI Logo Height</Label>
                    <Input id="bgmiLogoHeight" type="number" {...register("bgmiLogoHeight", { valueAsNumber: true })} />
                    {errors.bgmiLogoHeight && <p className="text-sm text-destructive">{errors.bgmiLogoHeight.message}</p>}
                </div>
            </div>

             <div className="space-y-2">
              <Label htmlFor="freeFireLogo">Free Fire Logo URL</Label>
              <Input id="freeFireLogo" {...register("freeFireLogo")} />
              {errors.freeFireLogo && <p className="text-sm text-destructive">{errors.freeFireLogo.message}</p>}
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="freeFireLogoWidth">Free Fire Logo Width</Label>
                    <Input id="freeFireLogoWidth" type="number" {...register("freeFireLogoWidth", { valueAsNumber: true })} />
                    {errors.freeFireLogoWidth && <p className="text-sm text-destructive">{errors.freeFireLogoWidth.message}</p>}
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="freeFireLogoHeight">Free Fire Logo Height</Label>
                    <Input id="freeFireLogoHeight" type="number" {...register("freeFireLogoHeight", { valueAsNumber: true })} />
                    {errors.freeFireLogoHeight && <p className="text-sm text-destructive">{errors.freeFireLogoHeight.message}</p>}
                </div>
            </div>
          </div>

          <div>
              <h4 className="text-lg font-medium mb-4">Color Theme (HSL Values)</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                      <Label htmlFor="theme.background">Background</Label>
                      <Input id="theme.background" {...register("theme.background")} />
                      {errors.theme?.background && <p className="text-sm text-destructive">{errors.theme.background.message}</p>}
                  </div>
                   <div className="space-y-2">
                      <Label htmlFor="theme.foreground">Foreground (Text)</Label>
                      <Input id="theme.foreground" {...register("theme.foreground")} />
                       {errors.theme?.foreground && <p className="text-sm text-destructive">{errors.theme.foreground.message}</p>}
                  </div>
                   <div className="space-y-2">
                      <Label htmlFor="theme.card">Card</Label>
                      <Input id="theme.card" {...register("theme.card")} />
                      {errors.theme?.card && <p className="text-sm text-destructive">{errors.theme.card.message}</p>}
                  </div>
                   <div className="space-y-2">
                      <Label htmlFor="theme.primary">Primary</Label>
                      <Input id="theme.primary" {...register("theme.primary")} />
                      {errors.theme?.primary && <p className="text-sm text-destructive">{errors.theme.primary.message}</p>}
                  </div>
                   <div className="space-y-2">
                      <Label htmlFor="theme.accent">Accent</Label>
                      <Input id="theme.accent" {...register("theme.accent")} />
                      {errors.theme?.accent && <p className="text-sm text-destructive">{errors.theme.accent.message}</p>}
                  </div>
                   <div className="space-y-2">
                      <Label htmlFor="theme.border">Border</Label>
                      <Input id="theme.border" {...register("theme.border")} />
                      {errors.theme?.border && <p className="text-sm text-destructive">{errors.theme.border.message}</p>}
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="theme.ring">Ring</Label>
                      <Input id="theme.ring" {...register("theme.ring")} />
                      {errors.theme?.ring && <p className="text-sm text-destructive">{errors.theme.ring.message}</p>}
                  </div>
              </div>
          </div>

          <Separator />
          
          <h3 className="text-xl font-bold font-headline text-primary">Product Packages</h3>
          <div>
            <h4 className="text-lg font-medium mb-2">BGMI Packages</h4>
            <div className="grid grid-cols-3 gap-2 mb-2 text-sm font-medium text-muted-foreground">
                <span>Name</span>
                <span>Price (INR)</span>
                <span>Bonus</span>
            </div>
            {getValues('bgmiPackages').map((pkg, index) => (
              <div key={pkg.id} className="grid grid-cols-3 gap-2 items-center mb-2">
                <Input {...register(`bgmiPackages.${index}.name`)} placeholder="Package Name" />
                <Input type="number" {...register(`bgmiPackages.${index}.price`, { valueAsNumber: true })} placeholder="Price" />
                <Input {...register(`bgmiPackages.${index}.bonus`)} placeholder="e.g., +10 UC" />
              </div>
            ))}
          </div>

          <div>
            <h4 className="text-lg font-medium mb-2 mt-6">Free Fire Packages</h4>
             <div className="grid grid-cols-3 gap-2 mb-2 text-sm font-medium text-muted-foreground">
                <span>Name</span>
                <span>Price (INR)</span>
                <span>Bonus</span>
            </div>
            {getValues('freeFirePackages').map((pkg, index) => (
               <div key={pkg.id} className="grid grid-cols-3 gap-2 items-center mb-2">
                <Input {...register(`freeFirePackages.${index}.name`)} placeholder="Package Name" />
                <Input type="number" {...register(`freeFirePackages.${index}.price`, { valueAsNumber: true })} placeholder="Price" />
                <Input {...register(`freeFirePackages.${index}.bonus`)} placeholder="e.g., +10 Diamonds" />
              </div>
            ))}
          </div>

          <Button type="submit">Save Changes</Button>
        </form>
      </CardContent>
    </Card>
  );
}
