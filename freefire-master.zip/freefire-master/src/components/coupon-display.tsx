'use client';

import { Copy, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Card } from './ui/card';

interface CouponDisplayProps {
  code: string;
}

export default function CouponDisplay({ code }: CouponDisplayProps) {
  const { toast } = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    toast({
      title: 'Copied!',
      description: `Coupon code ${code} has been copied to your clipboard.`,
      className: 'bg-accent text-accent-foreground border-accent-foreground/20',
    });
  };

  return (
    <Card className="flex items-center justify-center flex-wrap gap-4 p-4 rounded-lg shadow-lg bg-card/80 backdrop-blur-sm border-accent/40">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-accent/20 rounded-full">
          <Gift className="h-6 w-6 text-accent" />
        </div>
        <div className="text-sm">
          <p className="font-semibold text-foreground">
            Get 5% OFF Your Next Order! Use code:
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
         <p className="font-bold text-accent tracking-widest border-2 border-dashed border-accent/50 px-4 py-1 rounded-md">{code}</p>
         <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleCopy}>
              <Copy className="h-4 w-4" />
              <span className="sr-only">Copy coupon code</span>
         </Button>
      </div>
    </Card>
  );
}
