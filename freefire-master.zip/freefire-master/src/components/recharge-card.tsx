
'use client';

import { useState } from 'react';
import type { RechargePackage } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Wallet, X, Gift, Gem, Shield, Star, CheckCircle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import { COUPON_CODE } from '@/lib/config';
import { cn } from '@/lib/utils';
import { Label } from './ui/label';
import { Separator } from './ui/separator';

interface RechargeCardProps {
  pkg: RechargePackage;
  gameName: 'BGMI' | 'Free Fire';
  upiId: string;
}

export default function RechargeCard({ pkg, gameName, upiId }: RechargeCardProps) {
  const [playerId, setPlayerId] = useState('');
  const [coupon, setCoupon] = useState('');
  const [discountedPrice, setDiscountedPrice] = useState<number | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const finalPrice = discountedPrice !== null ? discountedPrice : pkg.price;
  const upiLink = `upi://pay?pa=${upiId}&pn=GameTopUp+Zone&am=${finalPrice}.00&cu=INR&tn=Topup for ${gameName} PlayerID ${playerId}`;

  const handleApplyCoupon = () => {
    if (coupon.toUpperCase() === COUPON_CODE.toUpperCase()) {
      const newPrice = Math.round(pkg.price * 0.95);
      setDiscountedPrice(newPrice);
      toast({
        title: "Coupon Applied!",
        description: `You've received a 5% discount.`,
        variant: 'default',
        className: 'bg-accent text-accent-foreground border-accent',
      });
    } else {
      toast({
        title: "Invalid Coupon",
        description: "The coupon code you entered is not valid.",
        variant: "destructive",
      });
    }
  };
  
  const handleRemoveCoupon = () => {
    setCoupon('');
    setDiscountedPrice(null);
  };

  const handleConfirmAndPay = () => {
    if (playerId) {
      window.location.href = upiLink;
    }
  };
  
  const handleDialogStateChange = (open: boolean) => {
      setIsDialogOpen(open);
      // Reset state if dialog is closed without confirming
      if (!open) {
          setPlayerId('');
          setCoupon('');
          setDiscountedPrice(null);
      }
  }

  const buttonText = gameName === 'BGMI' ? 'Recharge' : 'Top-Up';

  const parseCurrency = (text: string | undefined): { value: number; unit: string } => {
      if (!text) return { value: 0, unit: '' };
      const match = text.match(/(\d+)\s*(.*)/);
      if (match) {
        return { value: parseInt(match[1], 10), unit: match[2] };
      }
      return { value: 0, unit: '' };
  };

  const baseCurrency = parseCurrency(pkg.name);
  const bonusCurrency = parseCurrency(pkg.bonus);
  const totalCurrency = baseCurrency.value + bonusCurrency.value;
  const currencyUnit = baseCurrency.unit || bonusCurrency.unit;
  const Icon = currencyUnit === 'UC' ? Shield : Gem;
  
  return (
    <Card className={cn(
      "bg-card/80 border-primary/20 shadow-lg shadow-primary/10 transition-all hover:shadow-primary/20 hover:border-primary/40 hover:-translate-y-1 flex flex-col relative",
       pkg.bestSeller && "border-amber-400 shadow-amber-400/20"
      )}>
      {pkg.bestSeller && (
        <div className="absolute -top-3 right-4 bg-amber-400 text-amber-900 px-3 py-1 text-xs font-bold rounded-full flex items-center gap-1 shadow-lg">
          <Star className="h-4 w-4" />
          BEST SELLER
        </div>
      )}
      <CardHeader className="flex-grow">
        <CardTitle className="text-primary text-2xl font-bold flex items-center gap-2">
          <Icon className="h-6 w-6" />
          {totalCurrency} {currencyUnit}
        </CardTitle>
        <CardDescription className="text-lg font-semibold text-foreground flex items-center justify-between">
            <span>₹{pkg.price}</span>
           {pkg.bonus && (
             <span className="text-xs bg-accent/20 text-accent font-bold py-1 px-2 rounded-full flex items-center gap-1 border border-accent/40">
                <Gift className="h-3 w-3" />
                Bonus Included
            </span>
          )}
        </CardDescription>
      </CardHeader>
       <CardContent>
          <p className="text-xs text-muted-foreground text-center">
             {pkg.name}
            {pkg.bonus && ` + ${pkg.bonus}`}
          </p>
      </CardContent>
      <CardFooter>
        <AlertDialog open={isDialogOpen} onOpenChange={handleDialogStateChange}>
          <AlertDialogTrigger asChild>
            <Button variant="outline" className="w-full">
              <Wallet className="mr-2 h-4 w-4" />
              {buttonText}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
              <>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirm Your Purchase</AlertDialogTitle>
                  <AlertDialogDescription asChild>
                    <div className="space-y-4 mt-4 text-left">
                      
                      <div className="space-y-2">
                        <Label htmlFor={`playerId-popup-${pkg.id}`} className="font-medium text-foreground">Player ID</Label>
                          <div className="flex items-center gap-2">
                            <Input
                              id={`playerId-popup-${pkg.id}`}
                              type="text"
                              placeholder={`Enter your ${gameName} UID`}
                              value={playerId}
                              onChange={(e) => setPlayerId(e.target.value)}
                              className="bg-background"
                              autoFocus
                            />
                            {playerId && (
                                <Button variant="ghost" size="icon" onClick={() => setPlayerId('')} className="h-10 w-10 flex-shrink-0">
                                    <X className="h-4 w-4" />
                                    <span className="sr-only">Clear Player ID</span>
                                </Button>
                              )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">Make sure the Player ID / UID is correct.</p>
                      </div>

                      <Separator />

                      <div className="space-y-2">
                        <h4 className="font-medium text-foreground">Order Summary</h4>
                        <ul className="list-none space-y-1 text-muted-foreground text-sm p-3 bg-secondary rounded-md">
                          <li><strong>Game:</strong> {gameName}</li>
                          {playerId && <li><strong>Player ID:</strong> {playerId}</li>}
                          <li>
                            <strong>Package:</strong> {baseCurrency.value} {currencyUnit}
                            {bonusCurrency.value > 0 && ` + ${bonusCurrency.value} ${currencyUnit} (Bonus)`}
                            <span className="text-primary font-bold"> = {totalCurrency} {currencyUnit} Total</span>
                          </li>
                          {coupon && discountedPrice && <li><strong>Coupon:</strong> <span className="text-accent">{coupon.toUpperCase()}</span></li>}
                        </ul>
                      </div>

                      <Separator />

                      <div className="space-y-2">
                        <h4 className="font-medium text-foreground">
                          Have a Coupon? <Link href="/coupons" className="text-xs text-primary underline-offset-4 hover:underline">View Offers</Link>
                        </h4>
                        <div className="flex items-center gap-2">
                              <Input
                                  type="text"
                                  placeholder="Coupon Code"
                                  value={coupon}
                                  onChange={(e) => setCoupon(e.target.value)}
                                  className="bg-background"
                                  disabled={discountedPrice !== null}
                              />
                              {discountedPrice !== null ? (
                                  <Button variant="destructive" size="icon" onClick={handleRemoveCoupon} className="h-10 w-10 flex-shrink-0">
                                      <X className="h-4 w-4" />
                                      <span className="sr-only">Remove Coupon</span>
                                  </Button>
                              ) : (
                                  <Button variant="outline" size="sm" onClick={handleApplyCoupon} className="h-10" disabled={!coupon}>
                                      Apply
                                  </Button>
                              )}
                          </div>
                      </div>

                      <Separator />

                      <div className="space-y-2">
                        <h4 className="font-medium text-foreground">Final Price</h4>
                        <div className="text-primary font-bold text-3xl text-center p-4 bg-secondary rounded-md">
                            {discountedPrice !== null ? (
                              <div className="flex items-baseline justify-center gap-3">
                                <span className="line-through text-muted-foreground text-xl">₹{pkg.price}</span>
                                <span>₹{discountedPrice}</span>
                              </div>
                            ) : (
                              `₹${pkg.price}`
                            )}
                          </div>
                          {discountedPrice !== null && (
                            <p className="text-sm text-center text-accent flex items-center justify-center gap-2">
                                <CheckCircle className="h-4 w-4" />
                                <span>5% coupon discount applied!</span>
                            </p>
                          )}
                      </div>

                      <div className="text-xs text-muted-foreground pt-2">Your top-up will be delivered after payment. Please complete the <Link href="/submit-order" className="underline hover:text-primary">Submit Order</Link> form for fast delivery.</div>
                    </div>
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <Button id={`pay-button-${pkg.id}`} onClick={handleConfirmAndPay} className='bg-primary text-primary-foreground hover:bg-primary/90' disabled={!playerId}>
                    Confirm & Pay
                  </Button>
                </AlertDialogFooter>
              </>
          </AlertDialogContent>
        </AlertDialog>
      </CardFooter>
    </Card>
  );
}
