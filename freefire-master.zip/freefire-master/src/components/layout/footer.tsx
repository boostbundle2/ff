
'use client';

import Link from 'next/link';
import { Instagram, Mail, Gamepad2 } from 'lucide-react';
import LanguageSwitcher from '../language-switcher';
import { useTranslation } from '@/hooks/use-language';

export default function Footer() {
  const t = useTranslation();

  return (
    <footer className="border-t border-border/40 bg-background/95">
      <div className="container mx-auto px-4 py-8 md:px-6">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="flex flex-col gap-2 md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-2">
              <Gamepad2 className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg font-headline">GameTopUp Zone</span>
            </Link>
            <p className="text-sm text-muted-foreground max-w-sm">
              The most trusted and reliable source for instant in-game currency recharges for BGMI and Free Fire. Secure payments, fast delivery, and dedicated support.
            </p>
          </div>
          <div className="md:justify-self-center">
            <h3 className="font-semibold mb-4 text-foreground">{t('footer.quickLinks')}</h3>
            <ul className="space-y-2">
              <li><Link href="/bgmi" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.bgmiRecharge')}</Link></li>
              <li><Link href="/free-fire" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.freeFireTopUp')}</Link></li>
              <li><Link href="/submit-order" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.submitOrder')}</Link></li>
              <li><Link href="/coupons" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.coupons')}</Link></li>
              <li><Link href="/about" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.aboutUs')}</Link></li>
              <li><Link href="/contact" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.contactUs')}</Link></li>
            </ul>
          </div>
          <div className="md:justify-self-center">
            <h3 className="font-semibold mb-4 text-foreground">{t('footer.legal')}</h3>
            <ul className="space-y-2">
              <li><Link href="/privacy-policy" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.privacyPolicy')}</Link></li>
              <li><Link href="/terms-and-conditions" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.termsAndConditions')}</Link></li>
              <li><Link href="/refund-policy" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.refundPolicy')}</Link></li>
              <li><Link href="/delivery-policy" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.deliveryPolicy')}</Link></li>
               <li><Link href="/disclaimer" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.disclaimer')}</Link></li>
               <li><Link href="/sitemap" className="text-sm text-muted-foreground transition-colors hover:text-primary">{t('footer.sitemap')}</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-border/40 pt-6 text-center">
          <div className="flex justify-center items-center gap-6 mb-4">
              <a href="mailto:support@gametopup.zone" className="text-muted-foreground transition-colors hover:text-primary">
                <Mail className="h-5 w-5" />
                 <span className="sr-only">Email</span>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-muted-foreground transition-colors hover:text-primary">
                <Instagram className="h-5 w-5" />
                 <span className="sr-only">Instagram</span>
              </a>
              <LanguageSwitcher />
            </div>
          <p className="text-xs text-muted-foreground">
            {t('footer.copyright').replace('{year}', new Date().getFullYear().toString())}
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            {t('footer.notAffiliated')}
          </p>
        </div>
      </div>
    </footer>
  );
}
