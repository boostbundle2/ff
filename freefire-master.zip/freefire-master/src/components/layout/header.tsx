
'use client';

import Link from 'next/link';
import { Menu, Gamepad2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useTranslation } from '@/hooks/use-language';

export default function Header() {
  const pathname = usePathname();
  const t = useTranslation();

  const navLinks = [
    { href: '/', label: t('header.home') },
    { href: '/bgmi', label: t('header.bgmi') },
    { href: '/free-fire', label: t('header.freeFire') },
    { href: '/submit-order', label: t('header.submitOrder') },
    { href: '/contact', label: t('header.contact') },
  ];

  const NavLinkItems = (onClose?: () => void) => navLinks.map((link) => (
    <Link
      key={link.href}
      href={link.href}
      onClick={onClose}
      className={cn(
        "text-sm font-medium transition-colors hover:text-primary",
        pathname === link.href ? "text-primary" : "text-muted-foreground"
      )}
    >
      {link.label}
    </Link>
  ));

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur-sm">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <Gamepad2 className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg font-headline">GameTopUp Zone</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          {NavLinkItems()}
        </nav>

        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <SheetHeader className="mb-8">
                 <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
                 <Link href="/" className="flex items-center gap-2">
                    <Gamepad2 className="h-6 w-6 text-primary" />
                    <span className="font-bold text-lg font-headline">GameTopUp Zone</span>
                  </Link>
              </SheetHeader>
              <nav className="flex flex-col gap-6">
                {NavLinkItems(() => {
                  // A bit of a hack to close the sheet on navigation for mobile
                  document.querySelector('[data-radix-dialog-overlay]')?.dispatchEvent(new Event('click'));
                })}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
