'use client';

import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { submitOrderAction } from '@/lib/actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

const OrderSchema = z.object({
  game: z.enum(['bgmi', 'free-fire'], { required_error: 'Please select a game.' }),
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  playerId: z.string().min(5, { message: 'Player ID seems too short.' }),
  transactionId: z.string().min(10, { message: 'Please enter a valid Transaction ID.' }),
  screenshot: z.any().optional(),
});

type OrderFormValues = z.infer<typeof OrderSchema>;

export default function OrderSubmissionForm() {
  const { toast } = useToast();
  const [isPending, setIsPending] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    control,
  } = useForm<OrderFormValues>({
    resolver: zodResolver(OrderSchema),
  });

  const processForm = async (data: OrderFormValues) => {
    setIsPending(true);
    const formData = new FormData();
    Object.entries(data).forEach(([key, value]) => {
      if (key === 'screenshot' && value instanceof FileList && value.length > 0) {
        formData.append(key, value[0]);
      } else if (value) {
        formData.append(key, value.toString());
      }
    });

    const result = await submitOrderAction(null, formData);

    if (result.message.startsWith('Success')) {
      toast({
        title: 'Order Submitted',
        description: 'We have received your details and will process your order shortly.',
        variant: 'default',
      });
      reset();
    } else {
      toast({
        title: 'Submission Error',
        description: result.message,
        variant: 'destructive',
      });
    }
    setIsPending(false);
  };

  return (
    <form onSubmit={handleSubmit(processForm)} className="space-y-6 bg-card p-8 rounded-lg border border-primary/20">
      <div className="space-y-2">
        <Label htmlFor="game">Game</Label>
        <Controller
          name="game"
          control={control}
          render={({ field }) => (
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <SelectTrigger id="game" className="w-full bg-background">
                <SelectValue placeholder="Select a game" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bgmi">BGMI</SelectItem>
                <SelectItem value="free-fire">Free Fire</SelectItem>
              </SelectContent>
            </Select>
          )}
        />
        {errors.game && <p className="text-sm text-destructive">{errors.game.message}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="name">Your Name</Label>
        <Input id="name" {...register('name')} placeholder="Enter your full name" className="bg-background"/>
        {errors.name && <p className="text-sm text-destructive">{errors.name.message}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="playerId">UID or Player ID</Label>
        <Input id="playerId" {...register('playerId')} placeholder="Enter your in-game ID" className="bg-background"/>
        {errors.playerId && <p className="text-sm text-destructive">{errors.playerId.message}</p>}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="transactionId">Transaction ID</Label>
        <Input id="transactionId" {...register('transactionId')} placeholder="Enter the UPI transaction ID" className="bg-background"/>
        {errors.transactionId && <p className="text-sm text-destructive">{errors.transactionId.message}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="screenshot">Payment Screenshot</Label>
        <Input id="screenshot" type="file" {...register('screenshot')} className="bg-background file:text-foreground" />
        <p className="text-xs text-muted-foreground">Optional, but helps in faster verification.</p>
      </div>

      <Button type="submit" disabled={isPending} className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
        {isPending ? 'Submitting...' : 'Submit Order'}
      </Button>
    </form>
  );
}
