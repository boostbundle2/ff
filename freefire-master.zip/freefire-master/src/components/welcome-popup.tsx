
'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from './ui/button';
import { X } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

export default function WelcomePopup() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const hasVisited = localStorage.getItem('hasVisitedGameTopUpZone');
    if (!hasVisited) {
      const timer = setTimeout(() => {
        setIsOpen(true);
        localStorage.setItem('hasVisitedGameTopUpZone', 'true');
      }, 1500); // Show popup after 1.5 seconds

      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="bg-card/80 backdrop-blur-sm border-primary/30 p-0 max-w-2xl rounded-2xl overflow-hidden">
        <DialogTitle className="sr-only">Welcome to GameTopUp Zone</DialogTitle>
        <DialogDescription className="sr-only">A welcome pop-up to direct you to BGMI or Free Fire recharge pages.</DialogDescription>
        <div className="relative">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            className="absolute top-2 right-2 z-10 h-8 w-8 rounded-full bg-black/50 text-white hover:bg-black/70 hover:text-white"
          >
            <X className="h-5 w-5" />
            <span className="sr-only">Close</span>
          </Button>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center p-8">
            <div className="flex flex-col items-center justify-center text-center space-y-4">
              <h2 className="text-3xl font-bold font-headline text-primary">Welcome!</h2>
              <p className="text-foreground font-semibold text-lg leading-tight">
                Your #1 Destination for Game Top-Ups
              </p>
              <div className="flex flex-col gap-4 w-full">
                 <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90" onClick={handleClose}>
                    <Link href="/bgmi">Recharge BGMI</Link>
                 </Button>
                  <Button asChild variant="secondary" className="w-full" onClick={handleClose}>
                    <Link href="/free-fire">Top-Up Free Fire</Link>
                 </Button>
              </div>
            </div>
            
            <div className="relative space-y-4 hidden md:block">
                 <Link href="/bgmi" onClick={handleClose} className="group block transform transition-transform hover:scale-105 hover:z-10 relative">
                     <Image src="https://placehold.co/300x200.png" data-ai-hint="battlegrounds mobile india" alt="BGMI" width={300} height={200} className="rounded-xl shadow-lg"/>
                     <span className="absolute bottom-2 left-2 bg-black/60 text-white text-sm font-bold px-2 py-1 rounded">BGMI</span>
                 </Link>
                 <Link href="/free-fire" onClick={handleClose} className="group block transform transition-transform hover:scale-105 hover:z-10 relative">
                     <Image src="https://placehold.co/300x200.png" data-ai-hint="garena free fire" alt="Free Fire" width={300} height={200} className="rounded-xl shadow-lg"/>
                      <span className="absolute bottom-2 left-2 bg-black/60 text-white text-sm font-bold px-2 py-1 rounded">Free Fire</span>
                 </Link>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
