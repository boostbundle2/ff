'use client';

import { useState, useEffect } from 'react';
import { ShoppingCart, X } from 'lucide-react';
import { Card } from '@/components/ui/card';

const names = ['ProGamer47', 'Shadow_Striker', 'PhoenixQueen', 'Cosmic_Blaze', 'MysticSniper', 'AlphaPlayer', 'SavageHuntress'];
const items = ['60 UC', '325 UC', '660 UC', '100 Diamonds', '310 Diamonds', '520 Diamonds'];

const getRandomElement = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

export default function PurchaseToast() {
  const [isVisible, setIsVisible] = useState(false);
  const [purchase, setPurchase] = useState<{ name: string; item: string } | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (!isClient) return;

    const showRandomToast = () => {
      setPurchase({ name: getRandomElement(names), item: getRandomElement(items) });
      setIsVisible(true);

      setTimeout(() => {
        setIsVisible(false);
      }, 5000); // Toast visible for 5 seconds
    };

    // Initial delay before first toast
    const initialTimeout = setTimeout(showRandomToast, 5000);
    
    // Subsequent toasts
    const interval = setInterval(() => {
        showRandomToast();
    }, 12000); // Show a new toast every 12 seconds

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    }
  }, [isClient]);

  if (!isVisible || !purchase) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 animate-in slide-in-from-bottom fade-in">
        <Card className="flex items-center gap-4 p-4 pr-8 rounded-lg shadow-2xl bg-card/80 backdrop-blur-sm border-primary/20">
            <div className="p-2 bg-primary/20 rounded-full">
                 <ShoppingCart className="h-6 w-6 text-primary" />
            </div>
            <div className="text-sm">
                <p className="font-semibold text-foreground">
                    {purchase.name}
                </p>
                <p className="text-muted-foreground">
                    just purchased <span className="font-bold text-primary">{purchase.item}</span>
                </p>
            </div>
             <button
                onClick={() => setIsVisible(false)}
                className="absolute top-2 right-2 p-1 text-muted-foreground hover:text-foreground rounded-full"
            >
                <X className="h-4 w-4" />
            </button>
        </Card>
    </div>
  );
}
