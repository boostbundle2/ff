'use client';

import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Image from 'next/image';
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Player_X",
    avatar: "PX",
    image: "https://placehold.co/100x100.png",
    imageHint: "gamer avatar",
    review: "Super fast delivery! Got my UC in less than 5 minutes. Highly recommended for all BGMI players.",
    rating: 5,
  },
  {
    name: "DiamondQueen",
    avatar: "DQ",
    image: "https://placehold.co/100x100.png",
    imageHint: "gamer girl",
    review: "Finally, a trustworthy site for Free Fire diamonds. The UPI payment is so convenient. Will buy again!",
    rating: 5,
  },
  {
    name: "SniperGod",
    avatar: "SG",
    image: "https://placehold.co/100x100.png",
    imageHint: "gamer avatar",
    review: "I was skeptical at first, but the service is legit. The manual process gives me peace of mind. Great job!",
    rating: 5,
  },
  {
    name: "RushGamer",
    avatar: "RG",
    image: "https://placehold.co/100x100.png",
    imageHint: "neon avatar",
    review: "Best prices and quickest service I've found online. The 'Submit Order' form is easy to use.",
    rating: 5,
  },
  {
    name: "Mystic_Mira",
    avatar: "MM",
    image: "https://placehold.co/100x100.png",
    imageHint: "female gamer",
    review: "The coupon code gave me a nice discount! Love the little perks. Customer for life.",
    rating: 5,
  },
  {
    name: "Alpha_Arjun",
    avatar: "AA",
    image: "https://placehold.co/100x100.png",
    imageHint: "male gamer",
    review: "Flawless transaction every time. I've used this site for months for my BGMI UC needs.",
    rating: 5,
  },
  {
    name: "Savage_Sara",
    avatar: "SS",
    image: "https://placehold.co/100x100.png",
    imageHint: "gamer girl avatar",
    review: "The 'Best Seller' tag helped me choose a package, and it was the perfect amount of diamonds. Smart feature!",
    rating: 5,
  },
  {
    name: "Cosmic_Karan",
    avatar: "CK",
    image: "https://placehold.co/100x100.png",
    imageHint: "space gamer",
    review: "100% manual and 100% safe. I appreciate the care they take with each order.",
    rating: 5,
  },
  {
    name: "PhoenixPriya",
    avatar: "PP",
    image: "https://placehold.co/100x100.png",
    imageHint: "fire gamer girl",
    review: "I had a question and the support team responded super quickly through the contact form. Excellent service.",
    rating: 5,
  },
  {
    name: "Techie_Tanmay",
    avatar: "TT",
    image: "https://placehold.co/100x100.png",
    imageHint: "hacker avatar",
    review: "The website is clean, fast, and easy to navigate. A very professional setup.",
    rating: 5,
  },
  {
    name: "GamerGirl_Geeta",
    avatar: "GG",
    image: "https://placehold.co/100x100.png",
    imageHint: "girl with headphones",
    review: "I always get my Free Fire diamonds here. The bonus diamonds are a fantastic plus!",
    rating: 5,
  },
  {
    name: "Vikram_Valor",
    avatar: "VV",
    image: "https://placehold.co/100x100.png",
    imageHint: "warrior avatar",
    review: "No hidden fees, no nonsense. Just quick, easy top-ups. This is how it should be done.",
    rating: 5,
  },
  {
    name: "Anjali_Ace",
    avatar: "AA",
    image: "https://placehold.co/100x100.png",
    imageHint: "anime girl avatar",
    review: "The confirmation popup is very clear and helps me double-check my Player ID before paying. Love that feature.",
    rating: 5,
  },
  {
    name: "Rahul_Rage",
    avatar: "RR",
    image: "https://placehold.co/100x100.png",
    imageHint: "angry gamer",
    review: "Got my UC in the middle of a crucial match. These guys are lifesavers!",
    rating: 5,
  },
  {
    name: "Nisha_Ninja",
    avatar: "NN",
    image: "https://placehold.co/100x100.png",
    imageHint: "female ninja",
    review: "Safe, secure, and simple. GameTopUp Zone is my go-to for all my gaming currency.",
    rating: 5,
  }
];

export default function Testimonials() {
  return (
    <Carousel
      opts={{
        align: "start",
        loop: true,
      }}
      className="w-full max-w-xs sm:max-w-xl md:max-w-2xl lg:max-w-4xl mx-auto"
    >
      <CarouselContent>
        {testimonials.map((testimonial, index) => (
          <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
            <div className="p-1">
              <Card className="bg-background/80 border-primary/20 shadow-lg shadow-primary/10">
                <CardContent className="flex flex-col items-center text-center p-6 gap-4 min-h-[280px] justify-center">
                    <Avatar>
                        <Image src={testimonial.image} alt={testimonial.name} data-ai-hint={testimonial.imageHint} width={64} height={64} className="rounded-full" />
                        <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                    </Avatar>
                     <div className="flex gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < testimonial.rating ? "text-amber-400 fill-amber-400" : "text-muted-foreground"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground italic">"{testimonial.review}"</p>
                    <span className="font-semibold text-primary">{testimonial.name}</span>
                </CardContent>
              </Card>
            </div>
          </CarouselItem>
        ))}
      </CarouselContent>
      <CarouselPrevious />
      <CarouselNext />
    </Carousel>
  );
}
