'use client';

import { useState, useEffect } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';
import { cn } from '@/lib/utils';

export default function PageLoader() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [isFinished, setIsFinished] = useState(true);

  useEffect(() => {
    // On the initial load, we don't want to show the loader.
    // So we set it to finished.
    setIsFinished(true);
    setLoading(false);
  }, []);

  useEffect(() => {
    // When a navigation starts, we want to show the loader.
    // The finished state will be false, and loading will be true.
    // We use a short timeout to allow the browser to start rendering the new page.
    setLoading(true);
    setIsFinished(false);

    const timer = setTimeout(() => {
      // After the navigation is complete (new pathname),
      // we finish the loading animation and then hide the loader.
      setIsFinished(true);
      setTimeout(() => setLoading(false), 500); // Wait for animation to finish
    }, 100);

    return () => clearTimeout(timer);
  }, [pathname, searchParams]);

  // If we are not loading, we don't render anything.
  if (!loading) return null;

  return (
    <div
      className={cn(
        'page-loader',
        !isFinished && 'loading',
        isFinished && 'finished'
      )}
    />
  );
}
