'use client';

import { useState, useEffect } from 'react';
import { Copy, X, Gift } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const COUPON_CODE = "GAMEON5";

export default function CouponToast() {
  const [isVisible, setIsVisible] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Show the coupon toast after a delay, but only once per session.
    const hasSeenCoupon = sessionStorage.getItem('seenCoupon');
    if (!hasSeenCoupon) {
      const timer = setTimeout(() => {
        setIsVisible(true);
        sessionStorage.setItem('seenCoupon', 'true');
      }, 8000); // Show after 8 seconds

      return () => clearTimeout(timer);
    }
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(COUPON_CODE);
    toast({
      title: "Copied!",
      description: `Coupon code ${COUPON_CODE} has been copied to your clipboard.`,
    });
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 animate-in slide-in-from-bottom fade-in">
        <Card className="flex items-center gap-4 p-4 pr-8 rounded-lg shadow-2xl bg-card/80 backdrop-blur-sm border-accent/40">
            <div className="p-2 bg-accent/20 rounded-full">
                 <Gift className="h-6 w-6 text-accent" />
            </div>
            <div className="text-sm">
                <p className="font-semibold text-foreground">
                    Get 5% OFF Your Next Order!
                </p>
                <div className="flex items-center gap-2 mt-1">
                   <p className="text-muted-foreground">Use code:</p>
                   <p className="font-bold text-accent tracking-widest">{COUPON_CODE}</p>
                   <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleCopy}>
                        <Copy className="h-4 w-4" />
                   </Button>
                </div>
            </div>
             <button
                onClick={() => setIsVisible(false)}
                className="absolute top-2 right-2 p-1 text-muted-foreground hover:text-foreground rounded-full"
            >
                <X className="h-4 w-4" />
            </button>
        </Card>
    </div>
  );
}
