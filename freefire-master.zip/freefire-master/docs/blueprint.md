# **App Name**: TopUp Titans

## Core Features:

- Homepage Design: Showcase featured banner with UC & Diamonds graphics, including CTA buttons for "Recharge BGMI" and "Top-Up Free Fire".
- BGMI Recharge Page: Display package cards for BGMI UC recharge with details (60 UC - ₹89, 325 UC - ₹449, 660 UC - ₹899, 1800 UC - ₹2299, 3850 UC - ₹4499, 8100 UC - ₹8999). Each card includes a Game UID input field and a 'Pay Now via UPI' button with the correct UPI link.
- Free Fire Recharge Page: Present Free Fire Diamond recharge options with similar layout to BGMI, including (100 Diamonds - ₹79, 310 Diamonds - ₹249, 520 Diamonds - ₹399, 1060 Diamonds - ₹749, 2180 Diamonds - ₹1399, 5600 Diamonds - ₹3499). Each card should have the Game UID input and UPI payment link.
- Order Submission Form: Collect information for processing orders using a submission form that gathers 'Game' (BGMI/Free Fire), 'Name', 'UID or Player ID', 'Screenshot Upload', and 'Transaction ID', then submits data to admin email.
- Persistent Contact Section: Make the 'Contact Us' section visible on every page, so users can always report problems, make requests etc.
- Trust Section Implementation: Display the trust signals including the "Verified UPI", "Fast Recharge", "100% Manual" icons along with testimonial sliders that boost trust in your service

## Style Guidelines:

- Primary color: Electric blue (#7DF9FF) for a vibrant and modern gaming feel, referencing the requested neon color.
- Background color: Dark charcoal (#222222) to establish a strong contrast, providing the requested dark gaming theme.
- Accent color: Lime green (#32CD32) is used sparingly for interactive elements and highlights to draw attention and complement the overall neon aesthetic.
- Body and headline font: 'Space Grotesk', a proportional sans-serif with a techy, scientific feel
- Utilize flat design icons with neon gradients for visual appeal.
- Implement a mobile-first responsive design approach to guarantee a smooth experience on various devices.